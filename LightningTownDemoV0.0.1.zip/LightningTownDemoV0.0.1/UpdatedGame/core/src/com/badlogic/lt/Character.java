package com.badlogic.lt;

import com.badlogic.gdx.physics.box2d.Body;

public class Character {
    //added enums for animations
    public enum Dir {
        UP,
        RIGHT,
        DOWN,
        LEFT,
        FRONT,
        BACK;
    }

    //added enums for animations
    public enum State {
        IDLE,
        WALK,
        RUN,
        JUMP,
        THROWN,
        DEAD;
        //etc
    }

    public boolean busy = false, landed = true, og = false;
    public Body mychr;
    public State state;
    public Dir dir;

    public Character(Body chr) {
        this.mychr = chr;

        this.state = State.IDLE;
        this.dir = Dir.FRONT;
        this.busy = false;
    }
}
