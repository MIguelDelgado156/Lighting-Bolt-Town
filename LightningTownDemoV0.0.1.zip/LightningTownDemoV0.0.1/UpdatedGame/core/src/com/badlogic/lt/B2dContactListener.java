package com.badlogic.lt;


import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;

public class B2dContactListener implements ContactListener {
    private Model parent;

    public B2dContactListener(Model parent){
        this.parent = parent;
    }

    @Override
    public void beginContact(Contact contact) {

        Fixture fa = contact.getFixtureA();
        Fixture fb = contact.getFixtureB();

        if(fb.getBody().getUserData() == "Player" && fa.getBody().getUserData() == "Floor" || fb.getBody().getUserData() == "Floor" && fa.getBody().getUserData() == "Player"){
            Model.Jumping = false;
            Model.land = true;
        }

        if(fb.getBody().getUserData() == "Player" && fa.getBody().getUserData() == "Moving Block" || fb.getBody().getUserData() == "Moving Block" && fa.getBody().getUserData() == "Player"){
            Model.Jumping = false;
            Model.land = true;
        }

        if(fb.getBody().getUserData() == "Lightning" && fa.getBody().getUserData() == "Floor" || fb.getBody().getUserData() == "Floor" && fa.getBody().getUserData() == "Lightning" || fb.getBody().getUserData() == "Moving Block" && fa.getBody().getUserData() == "Lightning" || fb.getBody().getUserData() == "Lightning" && fa.getBody().getUserData() == "Moving Block"){
            Model.grounded = true;
        }

        if(fb.getBody().getUserData() == "Lightning" && fa.getBody().getUserData() == "House1" || fb.getBody().getUserData() == "House1" && fa.getBody().getUserData() == "Lightning"){
            Model.destroyed1 = true;
        }

        if(fb.getBody().getUserData() == "Lightning" && fa.getBody().getUserData() == "House12" || fb.getBody().getUserData() == "House2" && fa.getBody().getUserData() == "Lightning"){
            Model.destroyed2 = true;
        }

        if(fb.getBody().getUserData() == "Player" && fa.getBody().getUserData() == "NPC" || fb.getBody().getUserData() == "NPC" && fa.getBody().getUserData() == "Player"){
            Model.kicked = true;
            fb.getBody().applyLinearImpulse(parent.JumpingImpulse, parent.chars.mychr.getPosition(), true);
        }

        if(fb.getBody().getUserData() == "NPC" && fa.getBody().getUserData() == "Floor" || fb.getBody().getUserData() == "Floor" && fa.getBody().getUserData() == "NPC"){
            Model.OnGround = true;
        }
        else Model.OnGround = false;

        if(fb.getBody().getUserData() == "NPC" && fa.getBody().getUserData() == "Lightning" || fb.getBody().getUserData() == "Lightning" && fa.getBody().getUserData() == "NPC"){
            Model.npcdead = true;
        }
    }


    @Override
    public void endContact(Contact contact) {

        Fixture fa = contact.getFixtureA();
        Fixture fb = contact.getFixtureB();
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
    }
}
