package com.badlogic.lt.controller;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;

public class KeyboardControl implements InputProcessor {

    public boolean left;
    public boolean right;
    public boolean up;
    public boolean down;
    public boolean space;

    @Override
    public boolean keyDown(int keycode) {
        boolean keyProcessed = false;
        switch (keycode) // switch code base on the variable keycode
        {
            case Keys.A:  	// if keycode is the same as Keys.LEFT a.k.a 21
                left = true;	// do this
                keyProcessed = true;// we have reacted to a keypress
                break;
            case Keys.D: 	// if keycode is the same as Keys.LEFT a.k.a 22
                right = true;	// do this
                keyProcessed = true;// we have reacted to a keypress
                break;
            case Keys.SPACE: 		// if keycode is the same as Keys.LEFT a.k.a 19
                space = true;		// do this
                keyProcessed = true;// we have reacted to a keypress
                break;
            case Keys.S: 	// if keycode is the same as Keys.LEFT a.k.a 20
                down = true;	// do this
                keyProcessed = true;// we have reacted to a keypress
                break;
            case Keys.W:
                up = true;
                keyProcessed = true;
                break;
        }
        return keyProcessed;	//  return our peyProcessed flag
    }
    @Override
    public boolean keyUp(int keycode) {
        boolean keyProcessed = false;
        switch (keycode) // switch code base on the variable keycode
        {
            case Keys.A:  	// if keycode is the same as Keys.LEFT a.k.a 21
                left = false;	// do this
                keyProcessed = true;	// we have reacted to a keypress
                break;
            case Keys.D: 	// if keycode is the same as Keys.LEFT a.k.a 22
                right = false;	// do this
                keyProcessed = true;	// we have reacted to a keypress
                break;
            case Keys.SPACE: 		// if keycode is the same as Keys.LEFT a.k.a 19
                space = false;		// do this
                keyProcessed = true;	// we have reacted to a keypress
                break;
            case Keys.S: 	// if keycode is the same as Keys.LEFT a.k.a 20
                down = false;	// do this
                keyProcessed = true;	// we have reacted to a keypress
                break;
            case Keys.W:
                up = false;
                keyProcessed = true;
                break;
        }
        return keyProcessed;	//  return our peyProcessed flag
    }
    @Override
    public boolean keyTyped(char character) {
        return false;
    }
    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }
    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }
    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }
    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }

}
