package com.badlogic.lt;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.lt.Model;
import com.badlogic.lt.Character;

public class Renderer {
    Model map;
    OrthographicCamera cam;
    Texture player;
    Character cman;
    Animation<TextureRegion> playerIdle;
    Animation<TextureRegion> playerLeft;
    Animation<TextureRegion> playerRight;
    Animation<TextureRegion> playerThrownRight;
    Animation<TextureRegion> playerThrownLeft;
    Animation<TextureRegion> playerGetUp;
    private float stateTime;
    private Character.Dir direct;
    SpriteBatch batch = new SpriteBatch(5460);
    private float animSpeed = 0.2f;
    private boolean astart = false;
    private boolean afinish = false;

    public Renderer(Model mod, OrthographicCamera cama) {
        this.map = mod;
        this.cam = cama;

        initialAnim();
    }

    private void initialAnim() {
        int cols = 26, rows = 9;

        player = new Texture(Gdx.files.internal("Base_SpriteSheet.png"));
        TextureRegion[][] tmp = TextureRegion.split(player, player.getWidth()/cols, player.getHeight()/rows);

        TextureRegion[] walkIdle = new TextureRegion[4];
        TextureRegion[] walkRight = new TextureRegion[4];
        TextureRegion[] walkLeft = new TextureRegion[4];
        TextureRegion[] thrownLeft = new TextureRegion[4];
        TextureRegion[] thrownRight = new TextureRegion[4];
        TextureRegion[] getUp = new TextureRegion[5];

        walkIdle[0] = tmp[0][4];
        walkIdle[1] = tmp[0][5];
        walkIdle[2] = tmp[0][6];
        walkIdle[3] = tmp[0][5];

        walkRight[0] = tmp[1][0];
        walkRight[1] = tmp[1][1];
        walkRight[2] = tmp[1][2];
        walkRight[3] = tmp[1][1];

        walkLeft[0] = tmp[3][0];
        walkLeft[1] = tmp[3][1];
        walkLeft[2] = tmp[3][2];
        walkLeft[3] = tmp[3][1];

        thrownRight[0] = tmp[6][13];
        thrownRight[1] = tmp[6][9];
        thrownRight[2] = tmp[6][10];
        thrownRight[3] = tmp[6][19];

        getUp[0] = tmp[5][19];
        getUp[1] = tmp[5][20];
        getUp[2] = tmp[5][15];
        getUp[3] = tmp[5][16];
        getUp[4] = tmp[5][17];

        playerIdle = new Animation<TextureRegion>(animSpeed, walkIdle);
        playerLeft = new Animation<TextureRegion>(animSpeed, walkLeft);
        playerRight = new Animation<TextureRegion>(animSpeed,walkRight);
        //playerThrownLeft = new Animation<TextureRegion>(animSpeed,thrownLeft);
        playerThrownRight = new Animation<TextureRegion>(animSpeed,thrownRight);
        playerGetUp = new Animation<TextureRegion>(animSpeed,getUp);

        stateTime = 0f;

    }

    public void render(float delta) {

        batch.setProjectionMatrix(cam.combined);

        batch.begin();
        //draws basic sprite at player model
        renderPlayer(delta);
        renderChars(delta);
        batch.end();

    }

    private void renderPlayer(float delta) {
        stateTime += delta;
        TextureRegion currentFrame = null;
        direct = map.player.dir;

        switch(map.player.state) {
            case IDLE:
                    currentFrame = playerIdle.getKeyFrame(stateTime, true);
                    break;
            case RUN:
                    break;
            case JUMP:
                    break;
            case WALK:
                    if(direct == Character.Dir.RIGHT)
                        currentFrame = playerRight.getKeyFrame(stateTime, true);
                    else
                        currentFrame = playerLeft.getKeyFrame(stateTime, true);
                    break;
            case THROWN:
                    currentFrame = playerIdle.getKeyFrame(stateTime, true);
                    break;
        }

        batch.draw(currentFrame,map.player.mychr.getPosition().x-map.pwidth/2,map.player.mychr.getPosition().y-map.pheight/2,map.pwidth,map.pheight);

    }

    private void renderChars(float delta) {
        stateTime += delta;
        TextureRegion currentFrame = null;
        direct = map.chars.dir;
        if(map.chars.mychr.getUserData() == "LANDED") map.chars.landed = true;
        else map.chars.landed = false;

        switch(map.chars.state) {
            case IDLE:
                currentFrame = playerIdle.getKeyFrame(stateTime, true);
                break;
            case RUN:
                break;
            case JUMP:
                break;
            case WALK:
                if(direct == Character.Dir.RIGHT)
                    currentFrame = playerRight.getKeyFrame(stateTime, true);
                break;
            case THROWN:
                    if(!map.chars.landed || map.chars.mychr.getLinearVelocity().x != 0 || map.chars.mychr.getLinearVelocity().y != 0) {
                        if(!astart) {
                            stateTime = 0;
                            astart = true;
                        }

                        currentFrame = playerThrownRight.getKeyFrame(stateTime/2, false);

                    } else {
                        if(astart) {
                            stateTime = 0;
                            astart = false;
                        }

                        currentFrame = playerGetUp.getKeyFrame(stateTime/2, false);

                        if(playerGetUp.isAnimationFinished(stateTime/2)) {
                        map.chars.busy = false;
                        }

                    }
                    break;
        }

        batch.draw(currentFrame,map.chars.mychr.getPosition().x-map.pwidth/2,map.chars.mychr.getPosition().y-map.pheight/2,map.pwidth,map.pheight);

    }
}
