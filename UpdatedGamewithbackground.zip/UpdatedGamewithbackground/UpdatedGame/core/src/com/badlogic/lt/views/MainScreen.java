package com.badlogic.lt.views;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.lt.Model;
import com.badlogic.lt.Orchestrator;
import com.badlogic.lt.controller.KeyboardControl;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.lt.Renderer;


public class MainScreen implements Screen {

    SpriteBatch batch = new SpriteBatch(5460);
    Texture test = new Texture(Gdx.files.internal("lk_front.png"));
    private final KeyboardControl controller;
    private Orchestrator parent;
    private Model model;
    private Camera cam;
    private Box2DDebugRenderer debugRenderer;
    Texture player;
    Animation<TextureRegion> playerLeft;
    Animation<TextureRegion> playerRight;
    private float stateTime;
    Renderer stuff;

    public MainScreen(Orchestrator orchestrator){
        parent = orchestrator;
        cam = new OrthographicCamera(32,24);
        controller = new KeyboardControl();
        model = new Model(controller);
        debugRenderer = new Box2DDebugRenderer(true,true,true,true,true,true);

        stuff = new Renderer(model, (OrthographicCamera) cam);

    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(controller);
    }

    //try vector getDirection and getVelocity to set animations
    @Override
    public void render(float delta) {
        model.logicStep(delta);
        Gdx.gl.glClearColor(0f, 0f, 0f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        debugRenderer.render(model.world, cam.combined);

        stuff.render(delta);
    }

    @Override
    public void resize(int width, int height) {
        // TODO Auto-generated method stub
    }

    @Override
    public void pause() {
        // TODO Auto-generated method stub
    }

    @Override
    public void resume() {
        // TODO Auto-generated method stub
    }

    @Override
    public void hide() {
        // TODO Auto-generated method stub
    }

    @Override
    public void dispose() {
        // TODO Auto-generated method stub
        test.dispose();
        batch.dispose();
    }
}
