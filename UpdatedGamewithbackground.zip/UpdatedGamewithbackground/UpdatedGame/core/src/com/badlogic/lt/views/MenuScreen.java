package com.badlogic.lt.views;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.lt.Orchestrator;
import com.badlogic.gdx.scenes.scene2d.ui.Table;

public class MenuScreen implements Screen {

    private Orchestrator parent;
    private Stage stage;

    public MenuScreen(Orchestrator orchestrator){
        parent = orchestrator;

        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
    }


    @Override
    public void show() {

        Table table = new Table();
        table.setFillParent(true);
        table.setDebug(true);
        stage.addActor(table);

        //This is a free skin that includes buttons, files are in assets folder and the button type selected is based on the
        //Identifier in the next line
        Skin skin = new Skin(Gdx.files.internal("skin/clean-crispy-ui.json"));
        // \/ this can be changed to different types based on the .jason file. See the .jason file for the different types.
        TextButton newGame = new TextButton("New Game", skin);
        TextButton exit = new TextButton("Exit", skin);

        //Table is like an exel sheet to how the elements of a menu in place
        //table.add(newGame).fillX().uniformX() fills the screen with the table and populates the middle the newGame button skin from above
        //Then padding is added and the next button is rendered
        table.add(newGame).fillX().uniformX();
        table.row().pad(10, 0, 10, 0);
        table.add(exit).fillX().uniformX();

        //This controls what each button does
        //Is tillable so can add buttons and all you have to do is copy the same code as newGame.addlistener(new ChangeListerner()
        //and then all the operation.

        exit.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                Gdx.app.exit();
            }
        });

        newGame.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                parent.changeScreen(Orchestrator.APPLICATION);
            }
        });

    }

    @Override
    public void render(float delta) {
        //This renders the screen and makes the stage move forward in time so that its no longer static.
        Gdx.gl.glClearColor(0f, 0f, 0f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 20f));
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        //This adjust the size of the buttons on screen resize
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
        // TODO Auto-generated method stub
    }

    @Override
    public void resume() {
        // TODO Auto-generated method stub
    }

    @Override
    public void hide() {
        // TODO Auto-generated method stub
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
