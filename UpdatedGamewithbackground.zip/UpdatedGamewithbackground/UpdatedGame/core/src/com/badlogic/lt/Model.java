package com.badlogic.lt;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.lt.controller.KeyboardControl;

public class Model {

    private Body bodyd, bodys, bodyk;
    private KeyboardControl controller;
    private Vector2 JumpingImpulse = new Vector2(0, 20f);

    public World world;
    public Body player, MovingBlock, MovingBlock2, LightningBolt, floor, House, House2, floor2, MovingBlock3;
    public Character cman;

    public int Score = 2;
    public float pwidth, pheight;
    public static boolean Jumping = false , land = true, grounded = false, destroyed1 = false, destroyed2 = false;


    public Model(KeyboardControl cont){
        controller = cont;
        pwidth = 2;
        pheight = 2;
        world = new World(new Vector2(0,-10f), true);
        world.setContactListener(new B2dContactListener(this));
        floor = createFloor(0,-10, 50 ,1);
        floor2 = createFloor(-8, 8.5f, 2, 0.5f);
        //createObject();
        MovingBlock = createMovingObject(-19, -5, 3,0);
        MovingBlock2= createMovingObject(19, 0, -3, 0);
        MovingBlock3= createMovingObject(-19,5,3,0);
        BodyFactory bodyFactory = BodyFactory.getInstance(world);
        //create player
        player = bodyFactory.makeBoxPolyBody(0, -9, pwidth, pheight, BodyFactory.WOOD, BodyType.DynamicBody,true);

        //create lightning bolt

        LightningBolt = bodyFactory.makeBoxPolyBody(30,30,1,1,bodyFactory.STEEL,BodyType.DynamicBody);

        //create house

        House = bodyFactory.makeBoxPolyBody(10,-8,2,2,bodyFactory.STEEL,BodyType.StaticBody);
        House2 = bodyFactory.makeBoxPolyBody(-10,10,2,2,bodyFactory.STEEL,BodyType.StaticBody);

        House.setUserData("House1");
        player.setUserData("Player");
        LightningBolt.setUserData("Lightning");
        floor.setUserData("Floor");
        floor2.setUserData("Floor");
        House2.setUserData("House2");
        MovingBlock2.setUserData("Moving Block");
        MovingBlock.setUserData("Moving Block");
        MovingBlock3.setUserData("Moving Block");
        cman = new Character(player);

    }


    private void createObject(){

        //create a new body definition (type and location)
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.DynamicBody;
        bodyDef.position.set(0,0);

        // add it to the world
        bodyd = world.createBody(bodyDef);

        // set the shape (here we use a box 50 meters wide, 1 meter tall )
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(1, 1);

        // set the properties of the object ( shape, weight, restitution(bouncyness)
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1f;

        // create the physical object in our body)
        // without this our body would just be data in the world
        bodyd.createFixture(shape, 0.0f);

        // we no longer use the shape object here so dispose of it.
        shape.dispose();
    }

    private Body createFloor(float posx, float posy, float FloorWidth, float FloorHeight) {
        // create a new body definition (type and location)
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.StaticBody;
        bodyDef.position.x = posx;
        bodyDef.position.y = posy;
        // add it to the world
        bodys = world.createBody(bodyDef);
        // set the shape (here we use a box 50 meters wide, 1 meter tall )
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(FloorWidth, FloorHeight);
        // create the physical object in our body)
        // without this our body would just be data in the world
        bodys.createFixture(shape, 0.0f);
        // we no longer use the shape object here so dispose of it.
        shape.dispose();
        return bodys;
    }



    private Body createMovingObject(float posx,float posy, float VelocityX, float VelocityY){

        //create a new body definition (type and location)
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.KinematicBody;
        bodyDef.position.x = posx;
        bodyDef.position.y = posy;

        // add it to the world
        bodyk = world.createBody(bodyDef);

        // set the shape (here we use a box 50 meters wide, 1 meter tall )
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(1,0.5f);

        // set the properties of the object ( shape, weight, restitution(bouncyness)
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1f;

        // create the physical object in our body)
        // without this our body would just be data in the world
        bodyk.createFixture(shape, 0.0f);

        // we no longer use the shape object here so dispose of it.
        shape.dispose();

        bodyk.setLinearVelocity(VelocityX, VelocityY);
        return bodyk;
    }

    public void logicStep(float delta){

            if (controller.left) {
                player.applyForceToCenter(-20, 0, true);
            }
            if (controller.right) {
                player.applyForceToCenter(20, 0, true);
            }


        if(controller.up){
            if (!Jumping) {
                player.applyLinearImpulse( JumpingImpulse, player.getPosition(), true);
                Jumping = true;
                land = false;
            }
        }
        //check current direction
        Vector2 tmp = player.getLinearVelocity();
        if(tmp.x != 0) {
            cman.state = Character.State.WALK;

            if(tmp.x < 0) cman.dir = Character.Dir.LEFT;
            else cman.dir = Character.Dir.RIGHT;
        }
        else
            cman.state = Character.State.IDLE;

        if(controller.space){
            if(tmp.x < 0){
                LightningBolt.setTransform(player.getPosition().x - 5, player.getPosition().y + 5, 0);
                LightningBolt.applyForceToCenter(0,-40,true);
            } else {
                LightningBolt.setTransform(player.getPosition().x + 5, player.getPosition().y + 5, 0);
                LightningBolt.applyForceToCenter(0,-40,true);
            }
        }

        if(grounded){
            LightningBolt.setTransform(100,100,0);
            grounded = false;
        }

        if(destroyed1){
            House.setTransform(40,40,0);
            Score--;
            destroyed1 = false;
        }
        if(destroyed2){
            House2.setTransform(40,40,0);
            Score--;
            destroyed2 = false;
        }
        if(player.getPosition().x > 19){
            float temp = player.getPosition().y;
            player.setTransform(-19,temp,0);
        }
        if(player.getPosition().x < -20){
            float temp = player.getPosition().y;
            player.setTransform(18,temp,0);
        }

        if(MovingBlock.getPosition().x > 19){
            MovingBlock.setTransform(-19, -5,0);
        }
        if(MovingBlock2.getPosition().x < -19){
            MovingBlock2.setTransform(19,0,0);
        }
        if(MovingBlock3.getPosition().x > 19){
            MovingBlock3.setTransform(-19,5,0);
        }

        if(Score == 0){
            System.out.println("Win!");
        }

        world.step(delta , 3, 3);
    }
}
