package com.badlogic.lt;

import com.badlogic.gdx.Game;
import com.badlogic.lt.views.LoadingScreen;
import com.badlogic.lt.views.MainScreen;
import com.badlogic.lt.views.MenuScreen;

public class Orchestrator extends Game {
//This class handles all other calls and screens for the game
//To add a screen make an identifier and class and populate is as done in TutorialClass
    private LoadingScreen loadingScreen;
    private MenuScreen menuScreen;
    private MainScreen mainScreen;


    public final static int MENU = 0;
    public final static int APPLICATION = 2;

    @Override
    public void create () {
        //On game launch this sets the screen to the loadingScreen, see loading screen for additional info
        loadingScreen = new LoadingScreen(this);
        setScreen(loadingScreen);
    }


    public void show() {
        // TODO Auto-generated method stub
    }


    public void render(float delta) {
        // TODO Auto-generated method stub
    }


    public void resize(int width, int height) {
        // TODO Auto-generated method stub
    }


    public void pause() {
        // TODO Auto-generated method stub
    }


    public void resume() {
        // TODO Auto-generated method stub
    }


    public void hide() {
        // TODO Auto-generated method stub
    }


    public void dispose() {
        // TODO Auto-generated method stub
    }

    //This class handles the changing of screens, any new screens have to be added here in order to work
    public void changeScreen(int screen) {
        switch (screen) {
            case MENU:
                if (menuScreen == null) menuScreen = new MenuScreen(this);
                this.setScreen(menuScreen);
                break;
            case APPLICATION:
                if (mainScreen == null) mainScreen = new MainScreen(this);
                this.setScreen(mainScreen);
                break;
        }
    }
}
