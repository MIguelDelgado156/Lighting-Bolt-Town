package com.badlogic.lt;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.lt.views.LoadingScreen;
import com.badlogic.lt.views.LoadingScreen;

public class game extends ApplicationAdapter {


    @Override
    public void create () {

    }

    @Override
    public void render () {

    }

    @Override
    public void dispose () {

    }
}
