package com.badlogic.lt;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.lt.controller.KeyboardControl;
import com.badlogic.lt.Character;

public class Model {
    public World world;
    private Body bodyd;
    private Body bodys;
    private Body bodyk;
    private KeyboardControl controller;
    public Character player;
    public Character chars;
    public float pwidth, pheight;
    public static boolean Jumping = false;
    public static boolean land = true;
    //public BodyFactory bodyFactory;
    public Vector2 JumpingImpulse = new Vector2(0, 20f);

    public Model(KeyboardControl cont){
        controller = cont;

        world = new World(new Vector2(0,-10f), true);
        world.setContactListener(new B2dContactListener(this));
        createFloor();
        //createObject();
        createMovingObject();

        initialize();
    }


    private void createObject(){

        //create a new body definition (type and location)
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.DynamicBody;
        bodyDef.position.set(0,0);

        // add it to the world
        bodyd = world.createBody(bodyDef);

        // set the shape (here we use a box 50 meters wide, 1 meter tall )
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(1, 1);

        // set the properties of the object ( shape, weight, restitution(bouncyness)
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1f;

        // create the physical object in our body)
        // without this our body would just be data in the world
        bodyd.createFixture(shape, 0.0f);

        // we no longer use the shape object here so dispose of it.
        shape.dispose();
    }

    private void createFloor() {
        // create a new body definition (type and location)
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.StaticBody;
        bodyDef.position.set(0, -10);
        // add it to the world
        bodys = world.createBody(bodyDef);
        // set the shape (here we use a box 50 meters wide, 1 meter tall )
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(50, 1);
        // create the physical object in our body)
        // without this our body would just be data in the world
        bodys.createFixture(shape, 0.0f);
        // we no longer use the shape object here so dispose of it.
        shape.dispose();
    }



    private void createMovingObject(){

        //create a new body definition (type and location)
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.KinematicBody;
        bodyDef.position.set(0,-12);


        // add it to the world
        bodyk = world.createBody(bodyDef);

        // set the shape (here we use a box 50 meters wide, 1 meter tall )
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(1,1);

        // set the properties of the object ( shape, weight, restitution(bouncyness)
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1f;

        // create the physical object in our body)
        // without this our body would just be data in the world
        bodyk.createFixture(shape, 0.0f);

        // we no longer use the shape object here so dispose of it.
        shape.dispose();

        bodyk.setLinearVelocity(0, 0.75f);
    }

    public void logicStep(float delta){

        //checks if player is performing action
        if(!player.busy) {
            //movement in air is slowed
            int f = 20;
            if(!player.landed) f = 10;

            if (controller.left) {
                player.mychr.applyForceToCenter(-f, 0, true);
            }
            if (controller.right) {
                player.mychr.applyForceToCenter(f, 0, true);
            }
        }

            if (controller.space) {
                if (!Jumping) {
                    player.mychr.applyLinearImpulse(JumpingImpulse, player.mychr.getPosition(), true);
                    Jumping = true;
                    player.landed = false;
                }
            }

            check(player);
            check(chars);
        world.step(delta , 3, 3);
    }

    public void initialize() {
        //this function initially creates characters
        pwidth = 2;
        pheight = 2;

        BodyFactory bodyFactory = BodyFactory.getInstance(world);

        player = new Character(bodyFactory.makeBoxPolyBody(2, 2, pwidth, pheight, BodyFactory.WOOD, BodyType.DynamicBody,true));
        //put body creation in here
        chars = new Character(bodyFactory.makeBoxPolyBody(6, 2, pwidth, pheight, BodyFactory.WOOD, BodyType.DynamicBody,true));
    }

    private void check(Character x) {
        //set direction and state
        Vector2 tmp = x.mychr.getLinearVelocity();

        if(!x.busy) {
            if (tmp.x != 0) {
                x.state = Character.State.WALK;

                if (tmp.x < 0) x.dir = Character.Dir.LEFT;
                else x.dir = Character.Dir.RIGHT;
            } else
                x.state = Character.State.IDLE;
        }

    }
}
