//note to self upload walksheet in square format and test

package com.badlogic.lt;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Animate implements ApplicationListener {
    private static final int FROWS = 2, FCOLS = 2;

    Animation<TextureRegion> walk_animation;
    Texture walksheet;
    SpriteBatch spriteBatch;

    float stime;

    @Override
    public void create() {
        walksheet = new Texture(Gdx.files.internal("lt_walkleft.png"));

        TextureRegion[][] tmp = TextureRegion.split(walksheet, walksheet.getWidth() / FCOLS
                                                             , walksheet.getHeight() / FROWS);

        TextureRegion[] walkFrames = new TextureRegion[FCOLS * FROWS];
        int index = 0;
        for(int i = 0; i < FROWS; i++) {
            for(int j = 0; j < FCOLS; j++) {
                walkFrames[index] = tmp[i][j];
                index++;
            }
        }

        walk_animation = new Animation<TextureRegion>(1f/4f, walkFrames);

        spriteBatch = new SpriteBatch();
        stime = 0f;
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void render() {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); // Clear screen
        stime += Gdx.graphics.getDeltaTime(); // Accumulate elapsed animation time

        // Get current frame of animation for the current stateTime
        TextureRegion currentFrame = walk_animation.getKeyFrame(stime, true);
        spriteBatch.begin();
        spriteBatch.draw(currentFrame, 50, 50); // Draw current frame at (50, 50)
        spriteBatch.end();
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() { // SpriteBatches and Textures must always be disposed
        spriteBatch.dispose();
        walksheet.dispose();
    }
}
