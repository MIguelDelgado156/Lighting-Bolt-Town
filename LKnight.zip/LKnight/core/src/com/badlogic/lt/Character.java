package com.badlogic.lt;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.lt.Light;

public class Character implements Screen {
    Rectangle mask;
    Texture spriteSheet;
    Light game;

    public Character() {

    }

    public void create() {
        spriteSheet = new Texture(Gdx.files.internal("Knight2.png"));

        mask = new Rectangle();
        mask.x = 800/2-64/2;
        mask.y = 50;
        mask.width = 16;
        mask.height = 16;

    }

    @Override
    public void render(float delta) {
        game.batch.begin();

        game.batch.draw(spriteSheet, mask.x, mask.y, mask.width, mask.height);
        game.batch.end();
    }

    @Override
    public void show() {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        spriteSheet.dispose();
    }

}
